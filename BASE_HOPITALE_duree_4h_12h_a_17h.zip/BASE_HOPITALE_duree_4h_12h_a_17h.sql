create database hopitale;
create role hopitale login password 'hopitale';
ALTER DATABASE hopitale owner to hopitale;
Create table Grade(
    grade serial not null,
    prestation numeric not null,
    valeur varchar(100) not null,
    PRIMARY KEY(grade)
);
Create table personnel(
    numero_du_personnel serial not null,
    nom varchar(50) not null,
    grade integer not null,
    PRIMARY KEY(numero_du_personnel),
    FOREIGN KEY (grade) REFERENCES Grade(grade)
);
Create table sexe(
    id_sexe serial not null,
    valeur_sexe varchar(20) not null,
    PRIMARY KEY(id_sexe)
);
Create table Patient(
    numero_patient serial not null,
    nom_patient varchar(75),
    id_sexe integer,
    prenoms_patient varchar(100),
    adresse_patient varchar(100),
    telephone_patient varchar(30),
    email_patient varchar(100),
    poids_patient numeric(5,2),
    profession_patient varchar(50),
    dates_de_naissance_patient date,
    image_patient varchar(255),
    PRIMARY KEY (numero_patient),
    FOREIGN KEY (id_sexe) REFERENCES sexe(id_sexe)
);
Create table intervention(
    id_intervention serial not null,
    numero_du_personnel integer not null,
    numero_patient integer not null,
    date_d_intervention date not null,
    PRIMARY KEY (id_intervention),
    FOREIGN KEY (numero_du_personnel) REFERENCES personnel(numero_du_personnel),
    FOREIGN KEY (numero_patient) REFERENCES Patient(numero_patient)
);
Create table intervention_paye(
    id_intervention_paye serial not null,
    id_intervention integer not null,
    PRIMARY KEY (id_intervention_paye),
    FOREIGN KEY (id_intervention) REFERENCES intervention(id_intervention) 
);
Create table Patient_archive(
    id_patient_archive serial not null,
    numero_patient integer,
    PRIMARY key (id_patient_archive),
    FOREIGN KEY (numero_patient) REFERENCES Patient(numero_patient)
);
CREATE TABLE categorie_chambre(
    id_categorie_chambre serial not null,
    valeur varchar(20),
    prix numeric,
    nombre_lit integer,
    PRIMARY key (id_categorie_chambre)
);
Create table Localisation(
    localisation serial not null,
    numero_etage integer not null,
    numero_salle integer not null,
    PRIMARY KEY (localisation)
);
Create TABLE Chambre(
    numero_chambre serial not null,
    id_categorie_chambre integer,
    localisation integer,
    PRIMARY key (numero_chambre),
    FOREIGN KEY (id_categorie_chambre) REFERENCES categorie_chambre(id_categorie_chambre),
    FOREIGN KEY (localisation) REFERENCES Localisation(localisation)
);
Create table Hospitalisation(
    id_hospitalisation serial not null,
    numero_patient integer not null,
    numero_chambre integer not null,
    date_d_arrive date,
    date_de_sortie date,
    PRIMARY KEY (id_hospitalisation),
    FOREIGN KEY (numero_patient) REFERENCES Patient(numero_patient),
    FOREIGN key (numero_chambre) REFERENCES Chambre(numero_chambre)
);
create table Hospitalisation_paye(
    id_hospitalisation_paye serial not null,
    id_hospitalisation integer not null,
    PRIMARY key (id_hospitalisation_paye),
    FOREIGN KEY (id_hospitalisation) REFERENCES Hospitalisation(id_hospitalisation)
);
Create table Historique_de_paiement(
    id_historique_de_paiement serial not null,
    numero_patient integer not null,
    payeur varchar(100) not null,
    somme_verse numeric(10,2) not null,
    PRIMARY KEY (id_historique_de_paiement),
    FOREIGN KEY (numero_patient) REFERENCES Patient(numero_patient)
);

---INSERTION GRADE----
INSERT INTO Grade VALUES(1,20000,'INFIRMIER');
INSERT INTO Grade VALUES(2,35000,'MEDECIN GENERALISTE');
INSERT INTO Grade VALUES(3,50000,'MEDECIN SPECIALISTE');
INSERT INTO Grade VALUES(4,70000,'PROFESSEUR');
---INSETION PERSONNEL--

---INFIRMIER---
INSERT INTO personnel VALUES(1,'RADAMA',1);
INSERT INTO personnel VALUES(2,'RANDRIAMBELO',1);
INSERT INTO personnel VALUES(3,'ANDRIATAHIANA',1);
INSERT INTO personnel VALUES(4,'RATSIMOLOHA',1);
INSERT INTO personnel VALUES(5,'RAVARADOHA',1);
---MEDECIN GENERALISTE---
INSERT INTO personnel VALUES(6,'RALANTO',2);
INSERT INTO personnel VALUES(7,'RAHETILAHY',2);
INSERT INTO personnel VALUES(8,'RABEZAVAVANA',2);
INSERT INTO personnel VALUES(9,'RANDRIANJAKA',2);
INSERT INTO personnel VALUES(10,'RABEMOZARA',2);
---MEDECIN SPECIALISTE----
INSERT INTO personnel VALUES(11,'RAFARALAHY',3);
INSERT INTO personnel VALUES(12,'ANDRIAMBOZY',3);
INSERT INTO personnel VALUES(13,'RAZANACHANTALINA',3);
---PROFESSEUR----
INSERT INTO personnel VALUES(14,'RAKOTROKA',4);
INSERT INTO personnel VALUES(15,'BENZAMIN',4);

---INSERTION SEXE---
INSERT INTO sexe VALUES(1,'Masculin');
INSERT INTO sexe VALUES(2,'Feminin');

---INSERTION PATIENT----
INSERT INTO Patient VALUES(1,'RABENANDRASANA',1,'Jean Louis','Lot K1 Ambotrimanjaka','0334567598','RABENANDRASANA@gmail.com',50,'Cultivateur','1996-02-02','patient1.jpg');
INSERT INTO Patient VALUES(2,'RAJAONARIVELO',2,'Marceline','Lot P2 Itaosy Hopitaly','0338967598','RAJAONARIVELO@gmail.com',60,'Sage femme','1980-04-02','patient2.jpg');
INSERT INTO Patient VALUES(3,'RAINLAIHARIVONY',1,'Mamonjy','Lot P9 Andohalo','0338960998','RAINLAIHARIVONY@gmail.com',80,'Militaire','1990-04-02','patient3.jpg');
INSERT INTO Patient VALUES(4,'RANDRIATSIFERANA',2,'Vero','Lot T5 AmbatoBe','0338960098','RANDRIATSIFERANA@gmail.com',36,'Mpianatra','2009-07-02','patient4.jpg');
INSERT INTO Patient VALUES(5,'RANDRIANJAKA',1,'Lova','Lot A4 Cite Itaosy','0336760098','RANDRIANJAKA@gmail.com',50,'Mpianatra','2007-08-05','patient5.jpg');
INSERT INTO Patient VALUES(6,'RANDRIANJAKA',1,'Nathanael','Lot A4 Cite Itaosy','0336700098','RANDRIANJAKA12@gmail.com',65,'Mon pere','1974-07-02','patient6.jpg');
INSERT INTO Patient VALUES(7,'RANDRIANBOLOLONA',2,'Safidy','Lot A3 Andoharanofotsy','0336700098','RANDRIANBOLOLONA@gmail.com',65,'Professeur','1978-10-02','patient7.jpg');
INSERT INTO Patient VALUES(8,'ANDRANARIVO',1,'Lala','Lot A10 Besarety','0336700098','ANDRANARIVO@gmail.com',75,'Avocat','1970-07-02','patient8.jpg');
INSERT INTO Patient VALUES(9,'ANDRIANJATOVO',2,'Tanjona','Lot A6 Andoharanofotsy','0346900098','ANDRIANJATOVO@gmail.com',35,'Medecin','1979-11-02','patient9.jpg');

---INSERTION INTERVENTION--
INSERT INTO intervention VALUES(1,11,1,'2022-02-11');
INSERT INTO intervention VALUES(2,12,3,'2022-02-13');
INSERT INTO intervention VALUES(3,13,4,'2022-02-20');
INSERT INTO intervention VALUES(4,11,5,'2022-02-25');
INSERT INTO intervention VALUES(5,12,6,'2022-02-28');
---INSERTION INTERVENTION PAYE--
INSERT INTO intervention_paye VALUES(1,1);
INSERT INTO intervention_paye VALUES(2,2);
INSERT INTO intervention_paye VALUES(3,3);
INSERT INTO intervention_paye VALUES(4,4);


---INSERTION PATIENT_ARCHIVE---
INSERT INTO Patient_archive VALUES(1,7);
INSERT INTO Patient_archive VALUES(2,8);
---INSERTION LOCALISATION---
INSERT INTO Localisation VALUES(1,1,1);
INSERT INTO Localisation VALUES(2,1,2);
INSERT INTO Localisation VALUES(3,1,3);
INSERT INTO Localisation VALUES(4,2,1);
INSERT INTO Localisation VALUES(5,2,2);
INSERT INTO Localisation VALUES(6,3,1);

---INSERTION CATEGORIE_CHAMBRE---
INSERT INTO categorie_chambre VALUES(1,'Categorie_A',40000,1);
INSERT INTO categorie_chambre VALUES(2,'Categorie_B',20000,2);
INSERT INTO categorie_chambre VALUES(3,'Categorie_C',10000,4);

---INSERTION CHAMBRE---
INSERT INTO Chambre VALUES(1,1,1);
INSERT INTO Chambre VALUES(2,1,2);
INSERT INTO Chambre VALUES(3,1,3);
INSERT INTO Chambre VALUES(4,2,4);
INSERT INTO Chambre VALUES(5,2,5);
INSERT INTO Chambre VALUES(6,2,5);
INSERT INTO Chambre VALUES(7,3,6);
INSERT INTO Chambre VALUES(8,3,6);
INSERT INTO Chambre VALUES(9,3,6);

---INSERTION HOSPITALISATION---
INSERT INTO Hospitalisation VALUES(1,1,1,'2022-02-01','2022-02-15');
INSERT INTO Hospitalisation VALUES(2,8,2,'2022-03-01',null);
INSERT INTO Hospitalisation VALUES(3,2,3,'2022-02-04','2022-02-20');
INSERT INTO Hospitalisation VALUES(4,3,4,'2022-02-18','2022-02-25');
INSERT INTO Hospitalisation VALUES(5,4,5,'2022-02-23','2022-03-01');
INSERT INTO Hospitalisation VALUES(6,6,9,'2022-02-10','2022-02-20');

--INSERTION HOSPITALISATION PAYE---
INSERT INTO Hospitalisation_paye VALUES(1,1);
INSERT INTO Hospitalisation_paye VALUES(2,3);
INSERT INTO Hospitalisation_paye VALUES(3,4);
INSERT INTO Hospitalisation_paye VALUES(4,5);
INSERT INTO Hospitalisation_paye VALUES(5,6);
----VIEW-CHAMBRE----
CREATE OR REPLACE VIEW view_chambre as select Chambre.numero_chambre,Chambre.id_categorie_chambre,categorie_chambre.valeur,categorie_chambre.prix,categorie_chambre.nombre_lit,Localisation.numero_etage,Localisation.numero_salle from
Chambre join categorie_chambre on categorie_chambre.id_categorie_chambre = Chambre.id_categorie_chambre join localisation on Chambre.localisation = Localisation.localisation;

SELECT * FROM view_chambre;
---VIEW COUT SEJOUR---
CREATE OR REPLACE VIEW view_cout_sejour as select Hospitalisation.id_hospitalisation,Hospitalisation.date_de_sortie - Hospitalisation.date_d_arrive as sejour_en_nb_de_jour ,view_chambre.numero_salle as chambre,view_chambre.valeur as categorie,((Hospitalisation.date_de_sortie - Hospitalisation.date_d_arrive) * view_chambre.prix) as cout,Hospitalisation.date_d_arrive as date_de_debut,Hospitalisation.date_de_sortie 
from Hospitalisation join view_chambre on view_chambre.numero_chambre = Hospitalisation.numero_chambre;

select * from view_cout_sejour;
---VIEW INTERVENTION SUR LE PATIENT----
CREATE OR REPLACE VIEW view_intervention_sur_les_patient as 
select intervention.numero_patient,personnel.nom,grade.prestation from intervention join personnel on personnel.numero_du_personnel = intervention.numero_du_personnel join Grade on Grade.grade = personnel.grade;

select * from view_intervention_sur_les_patient;
---VIEW PERSONNEL---

CREATE OR REPLACE VIEW view_personnel as select personnel.numero_du_personnel,personnel.nom,Grade.prestation,Grade.valeur
from personnel join Grade on Grade.grade = personnel.grade;

select * from view_personnel;
---VIEW HOSPITALISATION---
CREATE OR REPLACE VIEW view_hospitalisation as 
select Hospitalisation.numero_patient,Patient.nom_patient,Patient.prenoms_patient,
view_chambre.valeur as categorie_chambre,view_chambre.numero_etage as niveau,view_chambre.numero_salle as salle,
SUM(view_cout_sejour.sejour_en_nb_de_jour) as duree_de_sejour ,patient.image_patient 
from Hospitalisation join view_chambre on view_chambre.numero_chambre = Hospitalisation.numero_chambre join patient on patient.numero_patient = Hospitalisation.numero_patient join  view_cout_sejour on view_cout_sejour.id_hospitalisation = Hospitalisation.id_hospitalisation
group by Hospitalisation.numero_patient,Patient.nom_patient,Patient.prenoms_patient,categorie_chambre,niveau,salle,patient.image_patient ;

select * from view_hospitalisation;
----VIEW INFO PATIENT---
CREATE OR REPLACE VIEW view_info_patient as select Patient.image_patient,Patient.numero_patient,Patient.nom_patient,Patient.dates_de_naissance_patient,sexe.valeur_sexe,Patient.poids_patient,patient.profession_patient,view_hospitalisation.salle,
view_hospitalisation.niveau as etage,view_hospitalisation.duree_de_sejour,patient.email_patient,patient.telephone_patient
from patient join view_hospitalisation on view_hospitalisation.numero_patient = patient.numero_patient join sexe on sexe.id_sexe = patient.id_sexe;

select * from view_info_patient;